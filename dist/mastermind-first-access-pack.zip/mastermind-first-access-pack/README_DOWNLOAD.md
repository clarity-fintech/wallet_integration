# Mastermind First Access Pack

Download via `clrt pack download mastermind`, then run `clrt pack verify mastermind`.
