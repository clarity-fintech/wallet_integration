#!/usr/bin/env bash
# One-shot First Access Pack verification — safe to paste/run (no inline comment traps).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT"

echo "== First Access Pack — mastermind verify =="
make first-access-sync
make first-access-verify
make first-access-export

echo "== Folder 02 local demos =="
bash first_access_pack/02_terminal_vector/inference/run_local.sh
bash first_access_pack/02_terminal_vector/proof_of_fidelity/run_proof_demo.sh
bash first_access_pack/02_terminal_vector/prism_cli/run_prism_cli.sh

if [[ -x zk_guest/verify_genesis_anchor.sh ]]; then
  echo "== ZK genesis anchor (partial scaffold) =="
  bash zk_guest/verify_genesis_anchor.sh
fi

if [[ -n "${CLRTY_ALPHA_TOKEN:-}" ]]; then
  echo "== Alpha API live probe (CLRTY_ALPHA_TOKEN set) =="
  if curl -sf -o /dev/null -w "%{http_code}" \
    -H "Authorization: Bearer ${CLRTY_ALPHA_TOKEN}" \
    http://127.0.0.1:8545/v1/alpha/topology/logs | grep -q 200; then
    echo "Alpha topology/logs: OK"
  else
    echo "Alpha probe: start clrty-api in another terminal:"
    echo "  CLRTY_ALPHA_TOKEN=\$CLRTY_ALPHA_TOKEN cargo run -p clrty-api"
    exit 1
  fi
else
  echo "Skip live Alpha probe (set CLRTY_ALPHA_TOKEN to test bearer routes)"
fi

echo ""
echo "All blocking gates passed. Reports:"
echo "  var/compliance/first_access_verify_report.json"
echo "  dist/first_access_kit.zip"
