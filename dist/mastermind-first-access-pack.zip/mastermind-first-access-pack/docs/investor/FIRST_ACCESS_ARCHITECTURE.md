# First Access — Architecture & Integration Plan

How the Volkov Mastermind pack maps to repo implementation. Status labels are honest.

---

## 1. Local backend optimization (PyTorch + MLX)

**Goal:** Run foundational datasets through local matrices on unified memory (Apple Silicon). Keep weight transformations **decoupled** from L1 commit pipelines until model-hash is declared.

| Component | Path | Status |
|-----------|------|--------|
| Feature pipeline | `vis_intelligence/feature_pipeline.py` | Partial |
| MLX / Torch inference | `vis_intelligence/inference_local.py` | Partial (optional deps) |
| Model hash CI | `scripts/audit/verify-model-hashes.sh` | Scaffold |
| DVC weights | `.gitattributes` LFS patterns | Partial |

```bash
cd vis_intelligence
python3 feature_pipeline.py --spread-bps 170 --cancel-rate 0.3
python3 inference_local.py --backend deterministic
```

---

## 2. State ingestion & RAG verification

**Goal:** Feed generation outputs through proprietary token algorithms; verify factual fidelity before broadcasting payloads to the network.

| Step | Implementation |
|------|----------------|
| Genesis anchor | SHA-256 over `genesis_entropy.json` |
| Allocation sum | Must equal 16M buckets |
| Mint authority | Must be `null` |
| RAG gate script | `vis_intelligence/rag_verify.py` |

Fails closed: `rag_gate_pass: false` blocks recommended broadcast in operator runbooks.

---

## 3. ZK & confidential layers (planned)

**Goal:** Wrap transaction verification in succinct schemes (RISC Zero, Zama fhEVM) so inference metadata stays confidential pre-finalize.

| Target | Repo scaffold | Status |
|--------|---------------|--------|
| Attestation blobs | `settlement/attestation_blob.rs` | Partial |
| Proof-of-Clarity | `state_manifold/` | Partial |
| RISC Zero guest | *Not in repo* | Planned |
| Zama confidential VM | *Not in repo* | Planned |

No mainnet claim until external audit + guest circuit land.

---

## 4. Cross-chain messaging (deferred)

**Goal:** LayerZero / Chainlink CCIP interfaces for verified state settlement across execution targets.

| Component | Path | Launch status |
|-----------|------|---------------|
| LayerZero OFTv2 | `bridge_perimeter/layerzero_oft/` | Deferred Phase 10 |
| Wormhole NTT | `bridge_perimeter/wormhole_ntt/` | Deferred |
| FMA contracts | `bridge_perimeter/fma/contracts/` | EVM scaffold only |
| Harmonizer | `supply_harmonizer.rs` | Deferred |

See [`DEFERRED_BRIDGE.md`](../l1_launch/DEFERRED_BRIDGE.md).

**L1-only launch:** All First Access stress tests run against `clrty-1` telemetry; cross-chain routes are documented but inactive.

---

## Verification runbook

```bash
make first-access-sync
cargo run -p clrty-api
curl -s http://127.0.0.1:8545/v1/alpha/telemetry | jq '.mev_deep_dive.gate_pass'
python3 vis_intelligence/rag_verify.py
make mev-deep-dive
```

---

## Related

- [`FIRST_ACCESS_PACK.md`](FIRST_ACCESS_PACK.md)
- [`TIER2_TECH_SPEC.md`](TIER2_TECH_SPEC.md)
- [`manifests/nexus_modules.json`](../../manifests/nexus_modules.json) — module `ai` → `vis_intelligence`
