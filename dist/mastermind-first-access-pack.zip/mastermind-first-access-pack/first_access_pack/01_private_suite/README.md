# Folder 01 — The Private Suite

High-conviction diligence artifacts. No marketing fluff.

| Asset | Path |
|-------|------|
| Tier 2 Tech Spec | [`docs/investor/TIER2_TECH_SPEC.md`](../../docs/investor/TIER2_TECH_SPEC.md) |
| Token ecosystem | [`docs/investor/tokenomics_model.md`](../../docs/investor/tokenomics_model.md) |
| Technical DD | [`docs/investor/technical_due_diligence.md`](../../docs/investor/technical_due_diligence.md) |
| Security synthesis | [`docs/investor/security_audit_report.md`](../../docs/investor/security_audit_report.md) |
| Live deck HUD | [`frontend/investor/treasury-exclusive.html`](../../frontend/investor/treasury-exclusive.html) |
| MEV deep-dive | [`var/compliance/mev_deep_dive_report.json`](../../var/compliance/mev_deep_dive_report.json) |

Pack manifest pointer: [`manifest.json`](manifest.json) → [`CLRTY_SUBSTRATE/boot/first_access_manifest.json`](../../CLRTY_SUBSTRATE/boot/first_access_manifest.json)
