# Computational Proof of Fidelity

RAG output verification before network broadcast — genesis anchor, hallucination isolation, vector structuring.

## Run

```bash
./run_proof_demo.sh
# → var/compliance/rag_fidelity_report.json
```

Or directly:

```bash
python3 vis_intelligence/rag_verify.py \
  --demo first_access_pack/02_terminal_vector/proof_of_fidelity/sample_dataset
```

## Sample dataset

| Path | Expected |
|------|----------|
| `sample_dataset/rag_outputs/valid_allocation_summary.json` | PASS |
| `sample_dataset/rag_outputs/hallucinated_supply.json` | FAIL · `SUPPLY_INFLATION` |
| `sample_dataset/rag_outputs/drifted_mint_authority.json` | FAIL · `MINT_AUTHORITY_SET` |
| `sample_dataset/expected/` | Golden reports for regression |

Algorithm details: [`PROOF_OF_FIDELITY.md`](PROOF_OF_FIDELITY.md)

Implementation: [`vis_intelligence/rag_verify.py`](../../../vis_intelligence/rag_verify.py)
