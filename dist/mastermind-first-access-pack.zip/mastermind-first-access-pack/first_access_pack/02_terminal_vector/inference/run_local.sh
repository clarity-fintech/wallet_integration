#!/usr/bin/env bash
# Local VIS inference — deterministic path always works; optional MLX/Torch backend.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../../.." && pwd)"
cd "$ROOT"

BACKEND="deterministic"
while [[ $# -gt 0 ]]; do
  case "$1" in
    --backend) BACKEND="${2:-deterministic}"; shift 2 ;;
    --backend=*) BACKEND="${1#*=}"; shift ;;
    *) echo "Unknown arg: $1" >&2; exit 1 ;;
  esac
done

VENV="${ROOT}/var/sandbox/vis_venv"
if [[ ! -d "$VENV" ]]; then
  python3 -m venv "$VENV"
  # shellcheck disable=SC1091
  source "$VENV/bin/activate"
  pip -q install -r vis_intelligence/requirements.txt
else
  # shellcheck disable=SC1091
  source "$VENV/bin/activate"
fi

echo "== VIS local inference (backend=$BACKEND) =="
python3 vis_intelligence/inference_local.py --backend "$BACKEND"

echo "== Throughput bench =="
python3 first_access_pack/02_terminal_vector/inference/bench_throughput.py --backend "$BACKEND"

echo "Report: var/compliance/vis_throughput_report.json"
