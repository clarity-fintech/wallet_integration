# Local Hardware-Optimized Inference

Apple Silicon–first local backend. Weights decoupled from L1 until `model_hash` declared in `quant_skills_manifest.json`.

**Implementation:** [`vis_intelligence/`](../../../vis_intelligence/)

## Configs

| File | Backend |
|------|---------|
| `configs/mlx_default.yaml` | MLX unified memory (Apple Silicon) |
| `configs/torch_default.yaml` | PyTorch MPS fallback |

## Run

```bash
./run_local.sh                    # deterministic (no GPU deps)
./run_local.sh --backend mlx      # requires mlx
./run_local.sh --backend torch    # requires torch
python3 bench_throughput.py       # writes var/compliance/vis_throughput_report.json
```
