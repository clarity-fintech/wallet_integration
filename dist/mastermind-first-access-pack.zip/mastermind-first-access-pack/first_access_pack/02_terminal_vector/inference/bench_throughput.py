#!/usr/bin/env python3
"""Benchmark VIS feature pipeline + inference loop; emit compliance throughput report."""
from __future__ import annotations

import argparse
import json
import statistics
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
VIS = ROOT / "vis_intelligence"
sys.path.insert(0, str(VIS))

from feature_pipeline import feature_vector  # noqa: E402


def load_config(backend: str) -> dict:
    cfg_dir = Path(__file__).resolve().parent / "configs"
    name = "mlx_default.yaml" if backend == "mlx" else "torch_default.yaml"
    path = cfg_dir / name
    if not path.is_file():
        return {"backend": backend, "bench_iters": 100}
    try:
        import yaml  # type: ignore
    except ImportError:
        return {"backend": backend, "bench_iters": 100}
    return yaml.safe_load(path.read_text()) or {}


def run_deterministic_loop(iters: int, spread: float, cancel: float, volume: float) -> list[float]:
    latencies_ms: list[float] = []
    for _ in range(iters):
        t0 = time.perf_counter()
        feature_vector("bench", spread, cancel, volume)
        latencies_ms.append((time.perf_counter() - t0) * 1000.0)
    return latencies_ms


def run_backend_loop(backend: str, iters: int, spread: float, cancel: float) -> tuple[list[float], str]:
    if backend == "mlx":
        from inference_local import infer_mlx

        fn = lambda: infer_mlx(spread, cancel)  # noqa: E731
    elif backend == "torch":
        from inference_local import infer_torch

        fn = lambda: infer_torch(spread, cancel)  # noqa: E731
    else:
        fn = lambda: feature_vector("bench", spread, cancel, 0.2)  # noqa: E731

    latencies_ms: list[float] = []
    for _ in range(iters):
        t0 = time.perf_counter()
        fn()
        latencies_ms.append((time.perf_counter() - t0) * 1000.0)
    return latencies_ms, backend


def main() -> int:
    p = argparse.ArgumentParser(description="VIS throughput bench")
    p.add_argument("--backend", choices=["deterministic", "mlx", "torch"], default="deterministic")
    p.add_argument("--out", type=Path, default=ROOT / "var/compliance/vis_throughput_report.json")
    args = p.parse_args()

    cfg = load_config(args.backend if args.backend != "deterministic" else "mlx")
    iters = int(cfg.get("bench_iters", 100))
    warmup = int(cfg.get("warmup_iters", 5))
    spread = float(cfg.get("spread_bps", 170.0))
    cancel = float(cfg.get("cancel_rate", 0.3))
    volume = float(cfg.get("volume_norm", 0.2))

    if args.backend == "deterministic":
        run_deterministic_loop(warmup, spread, cancel, volume)
        latencies, backend = run_backend_loop("deterministic", iters, spread, cancel)
    else:
        run_backend_loop(args.backend, warmup, spread, cancel)
        latencies, backend = run_backend_loop(args.backend, iters, spread, cancel)

    elapsed_s = sum(latencies) / 1000.0
    samples_per_sec = iters / elapsed_s if elapsed_s > 0 else 0.0
    report = {
        "backend": backend,
        "bench_iters": iters,
        "samples_per_sec": round(samples_per_sec, 2),
        "latency_p50_ms": round(statistics.median(latencies), 4),
        "latency_p95_ms": round(sorted(latencies)[int(len(latencies) * 0.95) - 1], 4),
        "latency_mean_ms": round(statistics.mean(latencies), 4),
        "spread_bps": spread,
        "cancel_rate": cancel,
        "gate_pass": samples_per_sec > 0,
    }

    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))
    return 0 if report["gate_pass"] else 1


if __name__ == "__main__":
    sys.exit(main())
