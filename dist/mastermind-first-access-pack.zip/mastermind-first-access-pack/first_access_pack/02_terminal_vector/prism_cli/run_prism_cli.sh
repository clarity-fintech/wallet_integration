#!/usr/bin/env bash
# PRISM CLI gate for First Access Pack — build, smoke, queue demo.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../../.." && pwd)"
PRISM="${PRISM_ROOT:-$ROOT/clarity-prism-cli}"

if [[ ! -f "$PRISM/package.json" ]]; then
  PRISM="$ROOT/frontend/clarity-prism-cli"
fi

if [[ ! -f "$PRISM/package.json" ]]; then
  echo "FAIL: clarity-prism-cli not found. Clone: git clone https://github.com/williamsnameiswill/clarity-prism-cli.git" >&2
  exit 1
fi

cd "$PRISM"
echo "== PRISM CLI build ($PRISM) =="
npm install
npm run build
npm run build:terminal

CLI="node apps/cli/dist/index.js"
echo "== PRISM query smoke =="
$CLI prism query "arbitrage opportunities" >/dev/null

echo "== PRISM queue backlog demo =="
$CLI prism queue submit "scan liquidity|predict yield|risk exposure" >/dev/null
$CLI prism queue status

REPORT="$ROOT/var/compliance/prism_cli_gate_report.json"
mkdir -p "$(dirname "$REPORT")"
cat >"$REPORT" <<EOF
{
  "generated_at": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "gate_pass": true,
  "repo": "$PRISM",
  "cli_version": "$($CLI --version 2>/dev/null || echo 1.0.0)",
  "integrations": ["prism", "helix", "indexer", "settlement", "intelligence", "pipeline"],
  "queue": "serial-with-backlog"
}
EOF
echo "Wrote $REPORT"
echo "PRISM CLI gate: OK"
