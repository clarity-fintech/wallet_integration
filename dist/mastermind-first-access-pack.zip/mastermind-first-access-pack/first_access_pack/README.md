# Volkov Mastermind — First Access Pack

Exclusive deployment kit in the **same CLRTY monorepo**. Not public marketing.

| Folder | Purpose |
|--------|---------|
| [`01_private_suite/`](01_private_suite/README.md) | Tier 2 spec · tokenomics · live deck · MEV deep-dive |
| [`02_terminal_vector/`](02_terminal_vector/README.md) | Local inference · Closed Alpha API · RAG proof-of-fidelity |

## Quick verify (mastermind session)

Run **one command** (no inline `#` comments — those break `make` if pasted):

```bash
make first-access-mastermind
```

Or step-by-step:

```bash
make first-access-sync
make first-access-verify
make first-access-export
./first_access_pack/02_terminal_vector/inference/run_local.sh
./first_access_pack/02_terminal_vector/proof_of_fidelity/run_proof_demo.sh
```

Live Alpha API (replace `your-secret` with a real token — do not paste angle brackets):

```bash
export CLRTY_ALPHA_TOKEN=your-secret
cargo run -p clrty-api
curl -H "Authorization: Bearer $CLRTY_ALPHA_TOKEN" http://127.0.0.1:8545/v1/alpha/topology/logs
```

Portal (exclusive tier): [`frontend/investor/first-access-pack.html`](../frontend/investor/first-access-pack.html)

Manifest: [`CLRTY_SUBSTRATE/boot/first_access_manifest.json`](../CLRTY_SUBSTRATE/boot/first_access_manifest.json)
